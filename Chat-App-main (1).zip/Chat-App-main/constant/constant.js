const userspath ="users/";
const messagepath =(uId)=> `users/${uId}/messages/`;
const todospath = (uId) => `users/${uId}/todos/`;