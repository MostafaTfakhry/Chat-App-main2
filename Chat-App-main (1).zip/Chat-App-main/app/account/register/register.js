import Register from "../../../screens/Register";

export default function Page() {
  return (
   <Register/>
  );
}