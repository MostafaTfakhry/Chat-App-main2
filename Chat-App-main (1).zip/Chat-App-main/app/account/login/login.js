import Login from "../../../screens/Login";

export default function Page() {
  return (
   <Login/>
  );
}
