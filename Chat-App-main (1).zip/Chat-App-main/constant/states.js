import { useState } from "react";

const [constCredential,setConstCredential] =useState( {
    login: false
});
export{constCredential,setConstCredential};